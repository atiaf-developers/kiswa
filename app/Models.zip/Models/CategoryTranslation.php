<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CategoryTranslation extends MyModel {

    protected $table = "categoris_translations";
    protected $fillable=['title'];

 

}
